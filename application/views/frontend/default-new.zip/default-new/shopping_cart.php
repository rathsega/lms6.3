<?php include "breadcrumb.php"; ?>

<!------------ Cart section start ----->
<section class="cart-page">
    <div class="container" id="shoppingCart">
		<?php include "shopping_cart_inner_view.php"; ?>
    </div>
</section>
<!------------ Cart section end ----->