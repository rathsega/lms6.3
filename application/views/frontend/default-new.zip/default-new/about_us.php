<?php include "breadcrumb.php"; ?>

<!------- body section Start ------>
<section class="privacy-policy">
    <div class="container">
        <div class="row my-5">
            <div class="col-12">
                <?php echo get_frontend_settings('about_us'); ?>
            </div>
        </div>
    </div>
</section>
 <!------- body section end ------>